<?php

namespace App\Http\Controllers\ITSupport;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreCommentRequest;
use App\Models\Ticket;
use App\Models\TicketComment;
use App\Services\CommentService;

class CommentController extends Controller
{
    public function __construct(
        protected CommentService $service
    ) {
    }

    /**
     * Store Comment
     */
    public function store(
        StoreCommentRequest $request,
        Ticket $ticket
    ) {

        abort_unless(
            $ticket->assigned_to == auth()->id(),
            403
        );

        $this->service->create(
            // $ticket,
            // [
            //     'user_id' => auth()->id(),
            //     'comment' => $request->comment,
            //     'is_internal' => $request->boolean(
            //         'is_internal'
            //     ),
            // ]

            ticket: $ticket,
            comment: $request->comment,
            userId: auth()->id(),
            internal: $request->boolean('is_internal')
        );

        return back()->with(
            'success',
            'Komentar berhasil ditambahkan.'
        );

    }

    /**
     * Delete Comment
     */
    public function destroy(
        Ticket $ticket,
        TicketComment $comment
    ) {

        abort_unless(
            $ticket->assigned_to == auth()->id(),
            403
        );

        abort_unless(
            $comment->ticket_id == $ticket->id,
            404
        );

        $this->service->delete(
            $comment
        );

        return back()->with(
            'success',
            'Komentar berhasil dihapus.'
        );

    }

}