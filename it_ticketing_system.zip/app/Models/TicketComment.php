<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TicketComment extends Model
{   
    use HasFactory;
    protected $fillable = [

        'ticket_id',

        'user_id',

        'comment',

        'is_internal',

    ];

    protected $casts = [

        'is_internal' => 'boolean',

    ];

    /*
    |--------------------------------------------------------------------------
    | Relationship
    |--------------------------------------------------------------------------
    */

    public function ticket()
    {
        return $this->belongsTo(
            Ticket::class
        );
    }

    public function user()
    {
        return $this->belongsTo(
            User::class
        );
    }
}