<?php echo csrf_field(); ?>

<div class="card shadow-sm">

    <div class="card-header">

        <h5 class="mb-0">

            Ticket Information

        </h5>

    </div>

    <div class="card-body">

        <div class="row">

            
            <?php if(isset($ticket)): ?>

            <div class="col-md-4 mb-3">

                <label class="form-label">

                    Ticket Number

                </label>

                <input
                    type="text"
                    class="form-control"
                    value="<?php echo e($ticket->ticket_number); ?>"
                    readonly>

            </div>

            <?php endif; ?>

            
            <div class="col-md-8 mb-3">

                <label class="form-label">

                    Subject
                </label>

                <input
                    type="text"
                    name="subject"
                    class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    value="<?php echo e(old('subject',$ticket->subject ?? '')); ?>">

                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

        </div>

        
        <div class="mb-3">

            <label class="form-label">

                Description

            </label>

            <textarea
                name="description"
                rows="6"
                class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description',$ticket->description ?? '')); ?></textarea>

            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="invalid-feedback">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="row">

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Department

                </label>

                <select
                    name="department_id"
                    class="form-select <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                    <option value="">
                        -- Select Department --
                    </option>

                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option
                            value="<?php echo e($department->id); ?>"
                            <?php if(old('department_id',$ticket->department_id ?? '')==$department->id): echo 'selected'; endif; ?>>

                            <?php echo e($department->name); ?>


                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

                <?php $__errorArgs = ['department_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Priority

                </label>

                <select
                    name="priority_id"
                    class="form-select <?php $__errorArgs = ['priority_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                    <option value="">
                        -- Select Priority --
                    </option>

                    <?php $__currentLoopData = $priorities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $priority): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option
                            value="<?php echo e($priority->id); ?>"
                            <?php if(old('priority_id',$ticket->priority_id ?? '')==$priority->id): echo 'selected'; endif; ?>>

                            <?php echo e($priority->name); ?>


                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

                <?php $__errorArgs = ['priority_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

        </div>

        <div class="row">

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Category

                </label>

                <select
                    name="category_id"
                    id="category_id"
                    class="form-select <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                    <option value="">
                        -- Select Category --
                    </option>

                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option
                            value="<?php echo e($category->id); ?>"
                            <?php if(old('category_id',$ticket->category_id ?? '')==$category->id): echo 'selected'; endif; ?>>

                            <?php echo e($category->name); ?>


                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Sub Category

                </label>

                <select id="sub_category_id"
                    name="sub_category_id"
                    class="form-select <?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                    <option value="">
                        -- Select Sub Category --
                    </option>

                     sudah ambil dari ajax, jadi tidak perlu di foreach lagi, karena akan di load secara dinamis dari ajax

                </select>

                <?php $__errorArgs = ['sub_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

        </div>

        <div class="row">

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Assign To

                </label>

                <select
                    name="assigned_to"
                    class="form-select">

                    <option value="">
                        -- Not Assigned --
                    </option>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option
                            value="<?php echo e($user->id); ?>"
                            <?php if(old('assigned_to',$ticket->assigned_to ?? '')==$user->id): echo 'selected'; endif; ?>>

                            <?php echo e($user->name); ?>


                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>

            </div>

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Due Date

                </label>

                <input
                    type="datetime-local"
                    name="due_at"
                    class="form-control"
                    value="<?php echo e(old('due_at',isset($ticket->due_at) ? $ticket->due_at->format('Y-m-d\TH:i') : '')); ?>">

            </div>

        </div>

        <?php if(isset($ticket)): ?>

        <div class="row">

            
            <div class="col-md-6 mb-3">

                <label class="form-label">

                    Status

                </label>

                <select
                    name="status"
                    class="form-select"
                    >

                    <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option
                            value="<?php echo e($status); ?>"
                            <?php if(old('status',$ticket->status)==$status): echo 'selected'; endif; ?>>

                            <?php echo e(str_replace('_',' ',$status)); ?>


                        </option>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>


                
            </div>

        </div>

        <?php endif; ?>

    </div>

</div>

<div class="mt-4 d-flex justify-content-between">

    <a
        href="<?php echo e(route('tickets.index')); ?>"
        class="btn btn-secondary">

        Back

    </a>

    <button
        type="submit"
        class="btn btn-primary">

        Save Ticket

    </button>

</div>

<?php $__env->startPush('scripts'); ?>

<script>

document.addEventListener('DOMContentLoaded', function () {

    const category = document.getElementById('category_id');
    const subCategory = document.getElementById('sub_category_id');

    category.addEventListener('change', function () {

        const categoryId = this.value;

        subCategory.innerHTML =
            '<option value="">Loading...</option>';

        if (categoryId === '') {
            subCategory.innerHTML =
                '<option value="">-- Select Sub Category --</option>';
            return;
        }

        fetch('/sub-categories/by-category/' + categoryId)
            .then(response => response.json())
            .then(data => {

                let html =
                    '<option value="">-- Select Sub Category --</option>';

                data.forEach(item => {

                    html += `
                        <option value="${item.id}">
                            ${item.name}
                        </option>
                    `;

                });

                subCategory.innerHTML = html;

            })
            .catch(error => {

                console.error(error);

                subCategory.innerHTML =
                    '<option value="">Gagal Muat data sub-kategori</option>';

            });

    });

});

// Selected sub-category saat edit ticket

document.addEventListener('DOMContentLoaded', function () {

    const category = document.getElementById('category_id');
    const subCategory = document.getElementById('sub_category_id');

    const selectedSubCategory =
        "<?php echo e(old('sub_category_id', $ticket->sub_category_id ?? '')); ?>";

    function loadSubCategory(categoryId) {

        if (!categoryId) {
            subCategory.innerHTML =
                '<option value="">-- Select Sub Category --</option>';
            return;
        }

        fetch('/sub-categories/by-category/' + categoryId)
            .then(response => response.json())
            .then(data => {

                let html =
                    '<option value="">-- Select Sub Category --</option>';

                data.forEach(item => {

                    html += `
                        <option value="${item.id}"
                            ${selectedSubCategory == item.id ? 'selected' : ''}>
                            ${item.name}
                        </option>
                    `;

                });

                subCategory.innerHTML = html;

            });

    }

    category.addEventListener('change', function () {
        loadSubCategory(this.value);
    });

    if (category.value) {
        loadSubCategory(category.value);
    }

});

</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/tickets/form.blade.php ENDPATH**/ ?>