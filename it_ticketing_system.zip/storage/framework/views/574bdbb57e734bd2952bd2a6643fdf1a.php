<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        
        <div class="col-lg-4">

            
            <div class="card shadow-sm mb-3">

                <div class="card-body text-center">

                    <h4 class="mb-2">

                        <?php echo e($ticket->ticket_number); ?>


                    </h4>

                    <span class="badge bg-<?php echo e($ticket->status_badge_class ?? 'secondary'); ?> fs-6">

                        <?php echo e(str_replace('_',' ', $ticket->status)); ?>


                    </span>

                    <hr>

                    <h5>

                        <?php echo e($ticket->subject); ?>


                    </h5>

                    <p class="text-muted">

                        <?php echo e($ticket->priority->name); ?>


                    </p>

                </div>

            </div>

            
            <div class="card shadow-sm">

                <div class="card-header">

                    <strong>

                        Requester Information

                    </strong>

                </div>

                <div class="card-body">

                    <table class="table table-borderless mb-0">

                        <tr>

                            <th width="120">

                                Name

                            </th>

                            <td>

                                <?php echo e($ticket->requester->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Email

                            </th>

                            <td>

                                <?php echo e($ticket->requester->email); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Department

                            </th>

                            <td>

                                <?php echo e($ticket->department->name); ?>


                            </td>

                        </tr>

                    </table>

                </div>

            </div>

        </div>

        
        <div class="col-lg-8">

            <div class="card shadow-sm">

                <div class="card-header">

                    <strong>

                        Ticket Detail

                    </strong>

                </div>

                <div class="card-body">

                    <table class="table table-bordered">

                        <tr>

                            <th width="220">

                                Ticket Number

                            </th>

                            <td>

                                <?php echo e($ticket->ticket_number); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Subject

                            </th>

                            <td>

                                <?php echo e($ticket->subject); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Description

                            </th>

                            <td>

                                <?php echo nl2br(e($ticket->description)); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Category

                            </th>

                            <td>

                                <?php echo e($ticket->category->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Sub Category

                            </th>

                            <td>

                                <?php echo e($ticket->subCategory->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Priority

                            </th>

                            <td>

                                <?php echo e($ticket->priority->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Department

                            </th>

                            <td>

                                <?php echo e($ticket->department->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Assigned To

                            </th>

                            <td>

                                <?php echo e($ticket->assignee?->name ?? 'Not Assigned'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Due Date

                            </th>

                            <td>

                                <?php echo e($ticket->due_at?->format('d M Y H:i') ?? '-'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Created At

                            </th>

                            <td>

                                <?php echo e($ticket->created_at->format('d M Y H:i')); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Updated At

                            </th>

                            <td>

                                <?php echo e($ticket->updated_at->format('d M Y H:i')); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Updated By

                            </th>

                            <td>

                               <?php echo e($ticket->updatedBy?->name ?? 'Not Updated'); ?>


                            </td>

                        </tr>

                    </table>

                </div>

                <div class="card-footer d-flex justify-content-between">

                    <a
                        href="<?php echo e(route('tickets.index')); ?>"
                        class="btn btn-secondary">

                        Back

                    </a>

                    <div>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.update')): ?>

                        <a
                            href="<?php echo e(route('tickets.edit',$ticket)); ?>"
                            class="btn btn-warning">

                            Edit Ticket

                        </a>

                        <?php endif; ?>

                    </div>
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.assignment')): ?>

                            <a
                                href="<?php echo e(route('tickets.assignment.create',$ticket)); ?>"
                                class="btn btn-primary">

                                Assign Ticket

                            </a>

                            <?php endif; ?>
                    </div>

                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/tickets/show.blade.php ENDPATH**/ ?>