<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="card">

        <div class="card-header">

            <h4 class="mb-0">

                Edit Ticket

            </h4>

        </div>

        <div class="card-body">

            <form
                action="<?php echo e(route('tickets.update',$ticket)); ?>"
                method="POST">

                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>

                <?php echo $__env->make('tickets.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </form>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
// const selectedSubCategory =
//     "<?php echo e(old('sub_category_id', $ticket->sub_category_id ?? '')); ?>";

//     document.addEventListener('DOMContentLoaded', function () {

//     let category = document.getElementById('category_id');

//     let subCategory = document.getElementById('sub_category_id');
    

//     category.addEventListener('change', function () {

//         subCategory.innerHTML =
//             '<option value="">Loading...</option>';

//         fetch(
//             '/sub-categories/by-category/' + this.value
//         )

//         .then(response => response.json())

//         .then(data => {

//             let html =
//                 '<option value="">-- Select Sub Category --</option>';

//             data.forEach(function(item){

//             let selected =
//                 item.id == selectedSubCategory
//                     ? 'selected'
//                     : '';

//             html += `
//                 <option value="${item.id}" ${selected}>
//                     ${item.name}
//                 </option>
//             `;

//         });

//             subCategory.innerHTML = html;

//         });

//     });

// }
// if (category.value !== '') {
//     category.dispatchEvent(new Event('change'));
// }
// );
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/tickets/edit.blade.php ENDPATH**/ ?>