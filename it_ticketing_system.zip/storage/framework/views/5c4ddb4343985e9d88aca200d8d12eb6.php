<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h3>Department</h3>

        <a href="<?php echo e(route('departments.create')); ?>"
           class="btn btn-primary">

            + Add Department

        </a>

    </div>

    <?php if(session('success')): ?>

        <div class="alert alert-success">

            <?php echo e(session('success')); ?>


        </div>

    <?php endif; ?>

    

    
    <div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example2" class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>No</th>
										<th>Code</th>
										<th>Name</th>
										<th>Status</th>
										<th>Action</th>
										
									</tr>
								</thead>
								<tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($department->code); ?></td>
										<td><?php echo e($department->name); ?></td>
										<td>
											<?php if($department->is_active): ?>
												<span class="badge bg-success">Active</span>
											<?php else: ?>
												<span class="badge bg-danger">Inactive</span>
											<?php endif; ?>
										</td>
										<td>
                                            <a href="<?php echo e(route('departments.show',$department)); ?>" class="btn btn-info btn-sm">Detail</a>
                                            <a href="<?php echo e(route('departments.edit',$department)); ?>" class="btn btn-warning btn-sm">Edit</a>
                                            <form action="<?php echo e(route('departments.destroy',$department)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button onclick="return confirm('Delete this department?')" class="btn btn-danger btn-sm">Delete</button>
                                            </form>
                                        </td>
										
									</tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center">No data available.</td>
                                    </tr>
                                    <?php endif; ?>
																		
								</tbody>
								<tfoot>
									<tr>
										<th>No</th>
										<th>Code</th>
										<th>Name</th>
										<th>Status</th>
										<th>Action</th>
										
									</tr>
								</tfoot>
							</table>
						</div>
					</div>
				</div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
  

 
  
  <script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <!-- DataTables Buttons Extension (Wajib ada jika menggunakan opsi buttons) -->
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>

	 <script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
    <script>
      $(document).ready(function() {
          var table = $('#example2').DataTable({
              // 1. Aktifkan perubahan jumlah data per halaman
              lengthChange: true, 
              
              // 2. Tentukan pilihan opsi jumlah data (10, 20, 50, dan Semua)
              lengthMenu: [
                  [10, 20, 50, -1],
                  [10, 20, 50, "Semua"]
              ],
              
              // 3. Tentukan susunan elemen (dom): 
              // B = Buttons, l = length changing input, f = filtering input (search), 
              // r = processing, t = table, i = information, p = pagination
              dom: '<"row mb-3"<"col-md-6"l><"col-md-6"f>>' +
                   '<"row mb-3"<"col-md-6"B>>' +
                   '<"row"<"col-md-12"tr>>' +
                   '<"row mt-3"<"col-md-5"i><"col-md-7"p>>',
                   
              buttons: ['copy', 'excel', 'pdf', 'print']
          });
        
          table.buttons().container()
              .appendTo('#example2_wrapper .col-md-6:eq(0)');
      });
  </script>
  <script src="<?php echo e(asset('assets/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
  
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/departments/index.blade.php ENDPATH**/ ?>