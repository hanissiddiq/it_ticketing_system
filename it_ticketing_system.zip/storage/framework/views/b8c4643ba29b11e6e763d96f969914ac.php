<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <!-- ===========================
            PROFILE CARD
        ============================ -->

        <div class="col-lg-4">

            <div class="card shadow-sm">

                <div class="card-body text-center">

                    <?php if($user->avatar): ?>

                        <img
                            src="<?php echo e(asset('storage/'.$user->avatar)); ?>"
                            class="rounded-circle border shadow"
                            width="180"
                            height="180"
                            style="object-fit:cover;">

                    <?php else: ?>

                        <img
                            src="<?php echo e(asset('images/default-user.png')); ?>"
                            class="rounded-circle border shadow"
                            width="180"
                            height="180">

                    <?php endif; ?>

                    <h3 class="mt-3 mb-0">

                        <?php echo e($user->name); ?>


                    </h3>

                    <p class="text-muted">

                        <?php echo e($user->position ?: '-'); ?>


                    </p>

                    <?php if($user->is_active): ?>

                        <span class="badge bg-success">

                            Active

                        </span>

                    <?php else: ?>

                        <span class="badge bg-danger">

                            Inactive

                        </span>

                    <?php endif; ?>

                    <hr>

                    <div class="text-start">

                        <strong>

                            Roles

                        </strong>

                        <br><br>

                        <?php $__empty_1 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <span class="badge bg-primary mb-1">

                                <?php echo e($role->name); ?>


                            </span>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <span class="text-muted">

                                No Role Assigned

                            </span>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

        <!-- ===========================
            DETAIL
        ============================ -->

        <div class="col-lg-8">

            <div class="card shadow-sm">

                <div class="card-header">

                    <h5 class="mb-0">

                        User Information

                    </h5>

                </div>

                <div class="card-body">

                    <table class="table table-bordered">

                        <tr>

                            <th width="250">

                                Employee ID

                            </th>

                            <td>

                                <?php echo e($user->employee_id ?: '-'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Full Name

                            </th>

                            <td>

                                <?php echo e($user->name); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Email

                            </th>

                            <td>

                                <?php echo e($user->email); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Department

                            </th>

                            <td>

                                <?php echo e($user->department?->name ?: '-'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Position

                            </th>

                            <td>

                                <?php echo e($user->position ?: '-'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Phone

                            </th>

                            <td>

                                <?php echo e($user->phone ?: '-'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Email Verified

                            </th>

                            <td>

                                <?php if($user->email_verified_at): ?>

                                    <span class="badge bg-success">

                                        Verified

                                    </span>

                                    <br>

                                    <?php echo e($user->email_verified_at->format('d M Y H:i')); ?>


                                <?php else: ?>

                                    <span class="badge bg-danger">

                                        Not Verified

                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                        <tr>

                            <th>

                                Created At

                            </th>

                            <td>

                                <?php echo e($user->created_at->format('d F Y H:i')); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Updated At

                            </th>

                            <td>

                                <?php echo e($user->updated_at->format('d F Y H:i')); ?>


                            </td>

                        </tr>

                    </table>

                </div>

                <div class="card-footer">

                    <a
                        href="<?php echo e(route('users.index')); ?>"
                        class="btn btn-secondary">

                        Back

                    </a>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.update')): ?>

                    <a
                        href="<?php echo e(route('users.edit',$user)); ?>"
                        class="btn btn-warning">

                        Edit User

                    </a>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/users/show.blade.php ENDPATH**/ ?>