<?php $__env->startSection('title','Dashboard Helpdesk'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-md-3 mb-3">

            <div class="card border-primary">

                <div class="card-body text-center">

                    <h6>Total Ticket</h6>

                    <h2><?php echo e($data['totalTicket']); ?></h2>

                </div>

            </div>

        </div>

        <div class="col-md-3 mb-3">

            <div class="card border-secondary">

                <div class="card-body text-center">

                    <h6>New</h6>

                    <h2><?php echo e($data['newTicket']); ?></h2>

                </div>

            </div>

        </div>

        <div class="col-md-3 mb-3">

            <div class="card border-info">

                <div class="card-body text-center">

                    <h6>Assigned</h6>

                    <h2><?php echo e($data['assignedTicket']); ?></h2>

                </div>

            </div>

        </div>

        <div class="col-md-3 mb-3">

            <div class="card border-warning">

                <div class="card-body text-center">

                    <h6>In Progress</h6>

                    <h2><?php echo e($data['progressTicket']); ?></h2>

                </div>

            </div>

        </div>

    </div>

    <div class="row">

        <div class="col-md-3 mb-3">

            <div class="card border-dark">

                <div class="card-body text-center">

                    <h6>Pending</h6>

                    <h2><?php echo e($data['pendingTicket']); ?></h2>

                </div>

            </div>

        </div>

        <div class="col-md-3 mb-3">

            <div class="card border-success">

                <div class="card-body text-center">

                    <h6>Resolved</h6>

                    <h2><?php echo e($data['resolvedTicket']); ?></h2>

                </div>

            </div>

        </div>

        <div class="col-md-3 mb-3">

            <div class="card border-primary">

                <div class="card-body text-center">

                    <h6>Closed</h6>

                    <h2><?php echo e($data['closedTicket']); ?></h2>

                </div>

            </div>

        </div>

        <div class="col-md-3 mb-3">

            <div class="card border-danger">

                <div class="card-body text-center">

                    <h6>Cancelled</h6>

                    <h2><?php echo e($data['cancelledTicket']); ?></h2>

                </div>

            </div>

        </div>

    </div>

    <div class="card mt-3">

        <div class="card-header">

            <strong>

                10 Ticket Terbaru

            </strong>

        </div>

        <div class="card-body table-responsive">

            <table class="table table-bordered table-hover">

                <thead class="table-light">

                    <tr>

                        <th>No</th>

                        <th>Ticket</th>

                        <th>Subject</th>

                        <th>Requester</th>

                        <th>Priority</th>

                        <th>Status</th>

                        <th width="120">

                            Action

                        </th>

                    </tr>

                </thead>

                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $latestTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <tr>

                            <td>

                                <?php echo e($loop->iteration); ?>


                            </td>

                            <td>

                                <?php echo e($ticket->ticket_number); ?>


                            </td>

                            <td>

                                <?php echo e($ticket->subject); ?>


                            </td>

                            <td>

                                <?php echo e($ticket->requester->name); ?>


                            </td>

                            <td>

                               <?php

                                $priorityColor = match(strtolower($ticket->priority->name)){

                                    'low' => 'success',

                                    'medium' => 'warning',

                                    'high' => 'danger',

                                    'critical' => 'danger',

                                    default => 'secondary'

                                };

                            ?>

                            <span class="badge bg-<?php echo e($priorityColor); ?>">

                                <?php echo e($ticket->priority->name); ?>


                            </span>

                            </td>

                            <td>

                                <?php switch($ticket->status):

                            case ('NEW'): ?>
                                <span class="badge bg-secondary">
                                    NEW
                                </span>
                                <?php break; ?>

                            <?php case ('OPEN'): ?>
                                <span class="badge bg-info">
                                    OPEN
                                </span>
                                <?php break; ?>

                            <?php case ('ASSIGNED'): ?>
                                <span class="badge bg-primary">
                                    ASSIGNED
                                </span>
                                <?php break; ?>

                            <?php case ('IN_PROGRESS'): ?>
                                <span class="badge bg-warning text-dark">
                                    IN PROGRESS
                                </span>
                                <?php break; ?>

                            <?php case ('PENDING'): ?>
                                <span class="badge bg-dark">
                                    PENDING
                                </span>
                                <?php break; ?>

                            <?php case ('RESOLVED'): ?>
                                <span class="badge bg-success">
                                    RESOLVED
                                </span>
                                <?php break; ?>

                            <?php case ('CLOSED'): ?>
                                <span class="badge bg-success">
                                    CLOSED
                                </span>
                                <?php break; ?>

                            <?php case ('CANCELLED'): ?>
                                <span class="badge bg-danger">
                                    CANCELLED
                                </span>
                                <?php break; ?>

                            <?php default: ?>
                                <span class="badge bg-light text-dark">
                                    <?php echo e($ticket->status); ?>

                                </span>

                        <?php endswitch; ?>

                            </td>

                            <td>

                                <a
                                    href="<?php echo e(route('helpdesk.tickets.show',$ticket)); ?>"
                                    class="btn btn-info btn-sm">

                                    Detail

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="7" class="text-center">

                                Tidak ada data.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/helpdesk/dashboard.blade.php ENDPATH**/ ?>