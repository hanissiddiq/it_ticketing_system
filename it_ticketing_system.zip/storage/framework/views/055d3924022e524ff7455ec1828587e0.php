<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <form
        method="POST"
        action="<?php echo e(route('tickets.assignment.store',$ticket)); ?>">

        <?php echo $__env->make('tickets.assignment.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </form>

    <div class="card mt-4 shadow-sm">

        <div class="card-header">

            <h5 class="mb-0">

                Assignment History

            </h5>

        </div>

        <div class="table-responsive">

            <table class="table table-bordered table-hover mb-0">

                <thead>

                <tr>

                    <th width="50">

                        #

                    </th>

                    <th>

                        Assigned By

                    </th>

                    <th>

                        Assigned To

                    </th>

                    <th>

                        Date

                    </th>

                    <th>

                        Notes

                    </th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>

                            <?php echo e($loop->iteration); ?>


                        </td>

                        <td>

                            <?php echo e($history->assigner->name); ?>


                        </td>

                        <td>

                            <?php echo e($history->assignee->name); ?>


                        </td>

                        <td>

                            <?php echo e($history->assigned_at->format('d M Y H:i')); ?>


                        </td>

                        <td>

                            <?php echo e($history->notes); ?>


                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="5" class="text-center">

                            No Assignment History

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/tickets/assignment/create.blade.php ENDPATH**/ ?>