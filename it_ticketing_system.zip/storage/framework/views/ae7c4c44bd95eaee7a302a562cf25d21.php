<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" data-bs-theme="blue-theme">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?> - <?php echo e(__('Profile')); ?></title>

    <!-- Favicon -->
    <link rel="icon" href="<?php echo e(asset('assets/images/favicon-32x32.png')); ?>" type="image/png">

    <!-- Loader -->
    <link href="<?php echo e(asset('assets/css/pace.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('assets/js/pace.min.js')); ?>"></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/bootstrap-extended.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Material+Icons+Outlined" rel="stylesheet">

    <!-- Custom Theme Styles -->
    <link href="<?php echo e(asset('sass/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('sass/blue-theme.css')); ?>" rel="stylesheet">
  </head>

  <body>

    <!-- Main Wrapper -->
    <div class="container py-5">
      
      <!-- Page Header -->
      <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-4">
        <div class="breadcrumb-title pe-3 text-white h4 mb-0"><?php echo e(__('Profile')); ?></div>
        <div class="ps-3 ms-auto">
          <a href="javascript:history.back()" class="btn btn-outline-light rounded-5 px-4">
            <i class="bi bi-arrow-left me-2"></i>Kembali
          </a>
        </div>
      </div>

      <div class="row g-4">
        <!-- Form Update Informasi Profil -->
        <div class="col-12 col-lg-8 mx-auto">
          <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
              <h5 class="card-title fw-bold mb-3">Informasi Profil</h5>
              <?php echo $__env->make('profile.partials.update-profile-information-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
          </div>
        </div>

        <!-- Form Update Password -->
        <div class="col-12 col-lg-8 mx-auto">
          <div class="card border-0 shadow-sm rounded-4">
            <div class="card-body p-4">
              <h5 class="card-title fw-bold mb-3">Ubah Password</h5>
              <?php echo $__env->make('profile.partials.update-password-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
          </div>
        </div>

        <!-- Form Hapus Akun -->
        <div class="col-12 col-lg-8 mx-auto">
          <div class="card border-0 shadow-sm border-danger rounded-4">
            <div class="card-body p-4">
              <h5 class="card-title fw-bold text-danger mb-3">Hapus Akun</h5>
              <?php echo $__env->make('profile.partials.delete-user-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
          </div>
        </div>
      </div>

    </div>

  </body>
</html><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/profile/edit.blade.php ENDPATH**/ ?>