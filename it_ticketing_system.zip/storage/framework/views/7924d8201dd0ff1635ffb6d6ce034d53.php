<?php $__env->startSection('title','My Ticket'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">

            <h5 class="mb-0">

                My Ticket

            </h5>

            <a
                href="<?php echo e(route('requester.tickets.create')); ?>"
                class="btn btn-primary">

                <i class="bi bi-plus-circle"></i>

                Create Ticket

            </a>

        </div>

        <div class="card-body">

            <form
                method="GET"
                action="<?php echo e(route('requester.tickets.index')); ?>">

                <div class="row mb-3">

                    <div class="col-md-4">

                        <input
                            type="text"
                            name="search"
                            class="form-control"
                            placeholder="Search Ticket..."
                            value="<?php echo e(request('search')); ?>">

                    </div>

                    <div class="col-md-3">

                        <select
                            name="status"
                            class="form-select">

                            <option value="">

                                All Status

                            </option>

                            <?php $__currentLoopData = [
                                'NEW',
                                'ASSIGNED',
                                'IN_PROGRESS',
                                'PENDING',
                                'RESOLVED',
                                'CLOSED',
                                'CANCELLED'
                            ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($status); ?>"
                                    <?php if(request('status') == $status): echo 'selected'; endif; ?>>

                                    <?php echo e($status); ?>


                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>

                    <div class="col-md-2">

                        <button
                            class="btn btn-primary w-100">

                            Search

                        </button>

                    </div>

                    <div class="col-md-2">

                        <a
                            href="<?php echo e(route('requester.tickets.index')); ?>"
                            class="btn btn-secondary w-100">

                            Reset

                        </a>

                    </div>

                </div>

            </form>

            <div class="table-responsive">

                <table class="table table-bordered table-hover align-middle">

                    <thead class="table-light">

                        <tr>

                            <th width="60">

                                No

                            </th>

                            <th>

                                Ticket Number

                            </th>

                            <th>

                                Subject

                            </th>

                            <th>

                                Category

                            </th>

                            <th>

                                Priority

                            </th>

                            <th>

                                Assigned To

                            </th>

                            <th>

                                Status

                            </th>

                            <th>

                                Created At

                            </th>

                            <th width="120">

                                Action

                            </th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                            <tr>

                                <td>

                                    <?php echo e($tickets->firstItem() + $loop->index); ?>


                                </td>

                                <td>

                                    <?php echo e($ticket->ticket_number); ?>


                                </td>

                                <td>

                                    <?php echo e($ticket->subject); ?>


                                </td>

                                <td>

                                    <?php echo e($ticket->category?->name); ?>


                                </td>

                                <td>

                                    <?php echo e($ticket->priority?->name); ?>


                                </td>

                                <td>

                                    <?php echo e($ticket->assignee?->name ?? '-'); ?>


                                </td>

                                <td>

                                    <?php

                                        $badge = match($ticket->status){

                                            'NEW' => 'secondary',

                                            'ASSIGNED' => 'primary',

                                            'IN_PROGRESS' => 'warning',

                                            'PENDING' => 'dark',

                                            'RESOLVED' => 'success',

                                            'CLOSED' => 'info',

                                            'CANCELLED' => 'danger',

                                            default => 'secondary'

                                        };

                                    ?>

                                    <span class="badge bg-<?php echo e($badge); ?>">

                                        <?php echo e($ticket->status); ?>


                                    </span>

                                </td>

                                <td>

                                    <?php echo e($ticket->created_at->format('d M Y H:i')); ?>


                                </td>

                                <td>

                                    <a
                                        href="<?php echo e(route('requester.tickets.show',$ticket)); ?>"
                                        class="btn btn-sm btn-info">

                                        Detail

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                            <tr>

                                <td
                                    colspan="9"
                                    class="text-center">

                                    No ticket found.

                                </td>

                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div class="mt-3">

                <?php echo e($tickets->withQueryString()->links()); ?>


            </div>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/requester/tickets/index.blade.php ENDPATH**/ ?>