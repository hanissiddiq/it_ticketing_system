<!-- =====================================
=====================================
===================================== -->



<!-- <?php $__env->startSection('title','Dashboard Admin'); ?> -->

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Card Stats Row -->
    <div class="row row-cols-1 row-cols-sm-2 row-cols-lg-4 g-3 mb-4">
        
        <!-- Total Ticket -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-primary text-primary bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">confirmation_number</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['totalTicket']); ?></h4>
                            <p class="mb-0 text-secondary">Total Ticket</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- New -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-secondary text-secondary bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">mark_email_unread</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['newTicket']); ?></h4>
                            <p class="mb-0 text-secondary">New</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

       
        <!-- Assigned -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-info text-info bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">assignment_ind</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['assignedTicket']); ?></h4>
                            <p class="mb-0 text-secondary">Assigned</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- In Progress -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-warning text-warning bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">pending_actions</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['progressTicket']); ?></h4>
                            <p class="mb-0 text-secondary">In Progress</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Pending -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-warning text-warning bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">hourglass_empty</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['pendingTicket']); ?></h4>
                            <p class="mb-0 text-secondary">Pending</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Resolved -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-success text-success bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">task_alt</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['resolvedTicket']); ?></h4>
                            <p class="mb-0 text-secondary">Resolved</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Closed -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-primary text-primary bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">lock</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['closedTicket']); ?></h4>
                            <p class="mb-0 text-secondary">Closed</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Cancelled -->
        <div class="col">
            <div class="card rounded-4 mb-0 h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between gap-3">
                        <div class="wh-48 d-flex bg-danger text-danger bg-opacity-10 align-items-center justify-content-center rounded-circle">
                            <span class="material-icons-outlined">cancel</span>
                        </div>
                        <div class="text-end">
                            <h4 class="mb-0 fw-bold"><?php echo e($data['cancelledTicket']); ?></h4>
                            <p class="mb-0 text-secondary">Cancelled</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div><!--end row-->


    

    <!-- Table Section -->
    <div class="card rounded-4 border-0 shadow-sm mt-3">
        <div class="card-header bg-transparent py-3">
            <h6 class="mb-0 fw-bold">10 Ticket Terbaru</h6>
        </div>
        <div class="card-body table-responsive">
            <table class="table align-middle table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Ticket</th>
                        <th>Subject</th>
                        <th>Requester</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th width="120" class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $latestTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td class="fw-bold"><?php echo e($ticket->ticket_number); ?></td>
                            <td><?php echo e($ticket->subject); ?></td>
                            <td><?php echo e($ticket->requester->name); ?></td>
                            <td>
                                <?php
                                    $priorityColor = match(strtolower($ticket->priority->name)){
                                        'low' => 'success',
                                        'medium' => 'warning',
                                        'high' => 'danger',
                                        'critical' => 'danger',
                                        default => 'secondary'
                                    };
                                ?>
                                <span class="badge bg-<?php echo e($priorityColor); ?> bg-opacity-10 text-<?php echo e($priorityColor); ?> px-2 py-1">
                                    <?php echo e($ticket->priority->name); ?>

                                </span>
                            </td>
                            <td>
                                <?php switch($ticket->status):
                                    case ('NEW'): ?>
                                        <span class="badge bg-secondary bg-opacity-10 text-secondary px-2 py-1">NEW</span>
                                        <?php break; ?>
                                    <?php case ('OPEN'): ?>
                                        <span class="badge bg-info bg-opacity-10 text-info px-2 py-1">OPEN</span>
                                        <?php break; ?>
                                    <?php case ('ASSIGNED'): ?>
                                        <span class="badge bg-primary bg-opacity-10 text-primary px-2 py-1">ASSIGNED</span>
                                        <?php break; ?>
                                    <?php case ('IN_PROGRESS'): ?>
                                        <span class="badge bg-warning bg-opacity-10 text-warning px-2 py-1">IN PROGRESS</span>
                                        <?php break; ?>
                                    <?php case ('PENDING'): ?>
                                        <span class="badge bg-dark bg-opacity-10 text-dark px-2 py-1">PENDING</span>
                                        <?php break; ?>
                                    <?php case ('RESOLVED'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success px-2 py-1">RESOLVED</span>
                                        <?php break; ?>
                                    <?php case ('CLOSED'): ?>
                                        <span class="badge bg-success bg-opacity-10 text-success px-2 py-1">CLOSED</span>
                                        <?php break; ?>
                                    <?php case ('CANCELLED'): ?>
                                        <span class="badge bg-danger bg-opacity-10 text-danger px-2 py-1">CANCELLED</span>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <span class="badge bg-light text-dark px-2 py-1"><?php echo e($ticket->status); ?></span>
                                <?php endswitch; ?>
                            </td>
                            <td class="text-center">
                                <a href="<?php echo e(route('tickets.show', $ticket)); ?>" class="btn btn-outline-info btn-sm rounded-3">
                                    Detail
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center py-4 text-muted">
                                Tidak ada data.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>