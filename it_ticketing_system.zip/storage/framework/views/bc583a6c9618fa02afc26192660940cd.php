<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="d-flex justify-content-between mb-3">

        <h3>Category Management</h3>

        <a
            href="<?php echo e(route('categories.create')); ?>"
            class="btn btn-primary">

            + Add Category

        </a>

    </div>

    <?php if(session('success')): ?>

        <div class="alert alert-success">

            <?php echo e(session('success')); ?>


        </div>

    <?php endif; ?>

    <div class="card">

        <div class="card-body">
		<div class="table-responsive">

            <table id="example2" class="table table-bordered table-hover">

                <thead>

                <tr>
					<th width="70">No</th>

                    <th width="70">Code</th>

                    <th>Name</th>

                    <th width="80">Color</th>

                    <th width="90">Status</th>

                    <th width="200">Action</th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>
					<td><?php echo e($loop->iteration); ?></td>

                        <td>

                            <?php echo e($category->code); ?>


                        </td>

                        <td>

                            <?php echo e($category->name); ?>


                        </td>

                        <td>

                            <span
                                class="badge"
                                style="background: <?php echo e($category->color); ?>">

                                <?php echo e($category->color); ?>


                            </span>

                        </td>

                        <td>

                            <?php if($category->is_active): ?>

                                <span class="badge bg-success">

                                    Active

                                </span>

                            <?php else: ?>

                                <span class="badge bg-danger">

                                    Inactive

                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <a
                                href="<?php echo e(route('categories.show',$category)); ?>"
                                class="btn btn-info btn-sm">

                                Detail

                            </a>

                            <a
                                href="<?php echo e(route('categories.edit',$category)); ?>"
                                class="btn btn-warning btn-sm">

                                Edit

                            </a>

                            <form
                                action="<?php echo e(route('categories.destroy',$category)); ?>"
                                method="POST"
                                class="d-inline">

                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>

                                <button
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Delete this category?')">

                                    Delete

                                </button>

                            </form>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="5"
                            class="text-center">

                            No Data Available

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

            <?php echo e($categories->links()); ?>


        </div>
		</div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
  

 
  
  <script src="<?php echo e(asset('assets/plugins/datatable/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/plugins/datatable/js/dataTables.bootstrap5.min.js')); ?>"></script>

    <!-- DataTables Buttons Extension (Wajib ada jika menggunakan opsi buttons) -->
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/dataTables.buttons.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.bootstrap5.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.html5.min.js"></script>
  <script src="https://cdn.datatables.net/buttons/2.4.1/js/buttons.print.min.js"></script>

	 <script>
		$(document).ready(function() {
			$('#example').DataTable();
		  } );
	</script>
	
    <script>
      $(document).ready(function() {
          var table = $('#example2').DataTable({
              // 1. Aktifkan perubahan jumlah data per halaman
              lengthChange: true, 
              
              // 2. Tentukan pilihan opsi jumlah data (10, 20, 50, dan Semua)
              lengthMenu: [
                  [10, 20, 50, -1],
                  [10, 20, 50, "Semua"]
              ],
              
              // 3. Tentukan susunan elemen (dom): 
              // B = Buttons, l = length changing input, f = filtering input (search), 
              // r = processing, t = table, i = information, p = pagination
              dom: '<"row mb-3"<"col-md-6"l><"col-md-6"f>>' +
                   '<"row mb-3"<"col-md-6"B>>' +
                   '<"row"<"col-md-12"tr>>' +
                   '<"row mt-3"<"col-md-5"i><"col-md-7"p>>',
                   
              buttons: ['copy', 'excel', 'pdf', 'print']
          });
        
          table.buttons().container()
              .appendTo('#example2_wrapper .col-md-6:eq(0)');
      });
  </script>
  <script src="<?php echo e(asset('assets/plugins/simplebar/js/simplebar.min.js')); ?>"></script>
  
  <?php $__env->stopPush(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/categories/index.blade.php ENDPATH**/ ?>