<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    
    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">
                Ticket Management
            </h3>

            <small class="text-muted">
                Manage IT Helpdesk Tickets
            </small>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.create')): ?>

        <a
            href="<?php echo e(route('tickets.create')); ?>"
            class="btn btn-primary">

            <i class="bi bi-plus-circle"></i>

            Create Ticket

        </a>

        <?php endif; ?>

    </div>

    
    <?php if(session('success')): ?>

        <div class="alert alert-success">

            <?php echo e(session('success')); ?>


        </div>

    <?php endif; ?>

    <?php if(session('error')): ?>

        <div class="alert alert-danger">

            <?php echo e(session('error')); ?>


        </div>

    <?php endif; ?>

    
    <div class="card mb-3">

        <div class="card-body">

            <form method="GET">

                <div class="row">

                    <div class="col-md-10">

                        <input
                            type="text"
                            name="keyword"
                            class="form-control"
                            placeholder="Search Ticket Number, Subject, Status..."
                            value="<?php echo e(request('keyword')); ?>">

                    </div>

                    <div class="col-md-2 d-grid">

                        <button class="btn btn-primary">

                            Search

                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>

    
    <div class="card">

        <div class="table-responsive">

            <table class="table table-hover table-bordered align-middle mb-0">

                <thead class="table-light">

                <tr>

                    <th width="60">

                        #

                    </th>

                    <th width="170">

                        Ticket No

                    </th>

                    <th>

                        Subject

                    </th>

                    <th width="180">

                        Requester

                    </th>

                    <th width="170">

                        Category

                    </th>

                    <th width="130">

                        Priority

                    </th>

                    <th width="140">

                        Status

                    </th>

                    <th width="180">

                        Assigned

                    </th>

                    <th width="220">

                        Action

                    </th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>

                            <?php echo e($loop->iteration + (($tickets->currentPage()-1) * $tickets->perPage())); ?>


                        </td>

                        <td>

                            <strong>

                                <?php echo e($ticket->ticket_number); ?>


                            </strong>

                        </td>

                        <td>

                            <strong>

                                <?php echo e($ticket->subject); ?>


                            </strong>

                            <br>

                            <small class="text-muted">

                                <?php echo e(Str::limit($ticket->description,70)); ?>


                            </small>

                        </td>

                        <td>

                            <?php echo e($ticket->requester->name); ?>


                        </td>

                        <td>

                            <?php echo e($ticket->category->name); ?>


                            <br>

                            <small class="text-muted">

                                <?php echo e($ticket->subCategory->name); ?>


                            </small>

                        </td>

                        <td>

                            <?php

                                $priorityColor = match(strtolower($ticket->priority->name)){

                                    'low' => 'success',

                                    'medium' => 'warning',

                                    'high' => 'danger',

                                    'critical' => 'dark',

                                    default => 'secondary'

                                };

                            ?>

                            <span class="badge bg-<?php echo e($priorityColor); ?>">

                                <?php echo e($ticket->priority->name); ?>


                            </span>

                        </td>

                        <td>

                            <?php

                                $statusColor = match($ticket->status){

                                    'NEW' => 'secondary',

                                    'OPEN' => 'primary',

                                    'ASSIGNED' => 'info',

                                    'IN_PROGRESS' => 'warning',

                                    'PENDING' => 'dark',

                                    'ESCALATED' => 'danger',

                                    'RESOLVED' => 'success',

                                    'CLOSED' => 'success',

                                    'CANCELLED' => 'secondary',

                                    default => 'secondary'

                                };

                            ?>

                            <span class="badge bg-<?php echo e($statusColor); ?>">

                                <?php echo e(str_replace('_',' ',$ticket->status)); ?>


                            </span>

                        </td>

                        <td>

                            <?php if($ticket->assignee): ?>

                                <?php echo e($ticket->assignee->name); ?>


                            <?php else: ?>

                                <span class="text-muted">

                                    Not Assigned

                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.view')): ?>

                            <a
                                href="<?php echo e(route('tickets.show',$ticket)); ?>"
                                class="btn btn-info btn-sm">

                                Detail

                            </a>

                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.update')): ?>

                            <a
                                href="<?php echo e(route('tickets.edit',$ticket)); ?>"
                                class="btn btn-warning btn-sm">

                                Edit

                            </a>

                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.delete')): ?>

                            <form
                                action="<?php echo e(route('tickets.destroy',$ticket)); ?>"
                                method="POST"
                                class="d-inline">

                                <?php echo csrf_field(); ?>

                                <?php echo method_field('DELETE'); ?>

                                <button
                                    onclick="return confirm('Delete this ticket?')"
                                    class="btn btn-danger btn-sm">

                                    Delete

                                </button>

                            </form>

                            <?php endif; ?>

                       
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket.assignment')): ?>

                            <a
                                href="<?php echo e(route('tickets.assignment.create',$ticket)); ?>"
                                class="btn btn-primary btn-sm">

                                Assign

                            </a>

                            <?php endif; ?> 
                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="9"
                            class="text-center p-5">

                            <h5>

                                No Ticket Found

                            </h5>

                            <small class="text-muted">

                                Click Create Ticket to add a new ticket.

                            </small>

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

        <div class="card-footer">

            <?php echo e($tickets->links()); ?>


        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/tickets/index.blade.php ENDPATH**/ ?>