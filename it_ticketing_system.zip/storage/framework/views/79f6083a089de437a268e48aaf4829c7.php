<?php $__env->startSection('title', 'Dashboard IT Support'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row mb-4">

        <div class="col-md-3">

            <div class="card border-primary">

                <div class="card-body text-center">

                    <h6>Total Ticket</h6>

                    <h2 class="text-primary">
                        <?php echo e($data['myTicket']); ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-warning">

                <div class="card-body text-center">

                    <h6>In Progress</h6>

                    <h2 class="text-warning">
                        <?php echo e($data['progress']); ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-dark">

                <div class="card-body text-center">

                    <h6>Pending</h6>

                    <h2 class="text-dark">
                        <?php echo e($data['pending']); ?>

                    </h2>

                </div>

            </div>

        </div>

        <div class="col-md-3">

            <div class="card border-success">

                <div class="card-body text-center">

                    <h6>Resolved</h6>

                    <h2 class="text-success">
                        <?php echo e($data['resolved']); ?>

                    </h2>

                </div>

            </div>

        </div>

    </div>


    <div class="card">

        <div class="card-header">

            <div class="d-flex justify-content-between align-items-center">

                <h5 class="mb-0">
                    My Assigned Ticket
                </h5>

                <a href="<?php echo e(route('itsupport.tickets.index')); ?>"
                    class="btn btn-primary btn-sm">

                    View All Ticket

                </a>

            </div>

        </div>

        <div class="card-body table-responsive">

            <table class="table table-bordered table-hover align-middle">

                <thead class="table-light">

                <tr>

                    <th width="50">No</th>

                    <th>Ticket Number</th>

                    <th>Subject</th>

                    <th>Priority</th>

                    <th>Status</th>

                    <th width="180">Action</th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>

                            <?php echo e($loop->iteration); ?>


                        </td>

                        <td>

                            <?php echo e($ticket->ticket_number); ?>


                        </td>

                        <td>

                            <?php echo e($ticket->subject); ?>


                        </td>

                        <td>

                            <?php switch($ticket->priority->name):

                                case ('LOW'): ?>

                                    <span class="badge bg-success">

                                        LOW

                                    </span>

                                <?php break; ?>

                                <?php case ('MEDIUM'): ?>

                                    <span class="badge bg-primary">

                                        MEDIUM

                                    </span>

                                <?php break; ?>

                                <?php case ('HIGH'): ?>

                                    <span class="badge bg-warning text-dark">

                                        HIGH

                                    </span>

                                <?php break; ?>

                                <?php case ('CRITICAL'): ?>

                                    <span class="badge bg-danger">

                                        CRITICAL

                                    </span>

                                <?php break; ?>

                                <?php default: ?>

                                    <?php echo e($ticket->priority->name); ?>


                            <?php endswitch; ?>

                        </td>

                        <td>

                            <?php switch($ticket->status):

                                case ('ASSIGNED'): ?>

                                    <span class="badge bg-primary">

                                        ASSIGNED

                                    </span>

                                <?php break; ?>

                                <?php case ('IN_PROGRESS'): ?>

                                    <span class="badge bg-warning text-dark">

                                        IN PROGRESS

                                    </span>

                                <?php break; ?>

                                <?php case ('PENDING'): ?>

                                    <span class="badge bg-dark">

                                        PENDING

                                    </span>

                                <?php break; ?>

                                <?php case ('RESOLVED'): ?>

                                    <span class="badge bg-success">

                                        RESOLVED

                                    </span>

                                <?php break; ?>

                                <?php default: ?>

                                    <span class="badge bg-secondary">

                                        <?php echo e($ticket->status); ?>


                                    </span>

                            <?php endswitch; ?>

                        </td>

                        <td>

                            <a href="<?php echo e(route('itsupport.tickets.show',$ticket)); ?>"
                                class="btn btn-info btn-sm">

                                Detail

                            </a>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="6" class="text-center">

                            Tidak ada ticket yang ditugaskan.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/itsupport/dashboard.blade.php ENDPATH**/ ?>