<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    

    <div class="d-flex justify-content-between align-items-center mb-4">

        <div>

            <h3 class="mb-1">

                User Management

            </h3>

            <small class="text-muted">

                Manage system users

            </small>

        </div>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.create')): ?>

        <a
            href="<?php echo e(route('users.create')); ?>"
            class="btn btn-primary">

            <i class="bi bi-plus-circle"></i>

            Add User

        </a>

        <?php endif; ?>

    </div>

    

    <?php if(session('success')): ?>

        <div class="alert alert-success">

            <?php echo e(session('success')); ?>


        </div>

    <?php endif; ?>

    <?php if(session('error')): ?>

        <div class="alert alert-danger">

            <?php echo e(session('error')); ?>


        </div>

    <?php endif; ?>

    

    <div class="card mb-3">

        <div class="card-body">

            <form method="GET">

                <div class="row">

                    <div class="col-md-10">

                        <input
                            type="text"
                            name="keyword"
                            class="form-control"
                            value="<?php echo e(request('keyword')); ?>"
                            placeholder="Search employee id, name, email, position...">

                    </div>

                    <div class="col-md-2 d-grid">

                        <button
                            class="btn btn-primary">

                            Search

                        </button>

                    </div>

                </div>

            </form>

        </div>

    </div>

    

    <div class="card">

        <div class="table-responsive">

            <table class="table table-bordered table-hover align-middle mb-0">

                <thead class="table-light">

                <tr>

                    <th width="60">

                        #

                    </th>

                    <th width="90">

                        Avatar

                    </th>

                    <th>

                        Employee

                    </th>

                    <th>

                        Department

                    </th>

                    <th>

                        Position

                    </th>

                    <th width="180">

                        Roles

                    </th>

                    <th width="90">

                        Status

                    </th>

                    <th width="220">

                        Action

                    </th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>

                            <?php echo e($loop->iteration); ?>


                        </td>

                        <td class="text-center">

                            <?php if($user->avatar): ?>

                                <img
                                    src="<?php echo e(asset('storage/'.$user->avatar)); ?>"
                                    class="rounded-circle"
                                    width="55"
                                    height="55"
                                    style="object-fit:cover;">

                            <?php else: ?>

                                <img
                                    src="<?php echo e(asset('images/default-user.png')); ?>"
                                    class="rounded-circle"
                                    width="55"
                                    height="55">

                            <?php endif; ?>

                        </td>

                        <td>

                            <strong>

                                <?php echo e($user->name); ?>


                            </strong>

                            <br>

                            <small class="text-muted">

                                <?php echo e($user->employee_id); ?>


                            </small>

                            <br>

                            <small>

                                <?php echo e($user->email); ?>


                            </small>

                        </td>

                        <td>

                            <?php echo e($user->department?->name ?? '-'); ?>


                        </td>

                        <td>

                            <?php echo e($user->position ?? '-'); ?>


                        </td>

                        <td>

                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <span class="badge bg-primary">

                                    <?php echo e($role->name); ?>


                                </span>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </td>

                        <td>

                            <?php if($user->is_active): ?>

                                <span class="badge bg-success">

                                    Active

                                </span>

                            <?php else: ?>

                                <span class="badge bg-danger">

                                    Inactive

                                </span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.view')): ?>

                            <a
                                href="<?php echo e(route('users.show',$user)); ?>"
                                class="btn btn-info btn-sm">

                                Detail

                            </a>

                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.update')): ?>

                            <a
                                href="<?php echo e(route('users.edit',$user)); ?>"
                                class="btn btn-warning btn-sm">

                                Edit

                            </a>

                            <?php endif; ?>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('user.delete')): ?>

                            <form
                                action="<?php echo e(route('users.destroy',$user)); ?>"
                                method="POST"
                                class="d-inline">

                                <?php echo csrf_field(); ?>

                                <?php echo method_field('DELETE'); ?>

                                <button
                                    class="btn btn-danger btn-sm"
                                    onclick="return confirm('Delete this user ?')">

                                    Delete

                                </button>

                            </form>

                            <?php endif; ?>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td
                            colspan="8"
                            class="text-center p-5">

                            <h5>

                                No users found

                            </h5>

                            <small class="text-muted">

                                Click Add User to create a new user.

                            </small>

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

        <div class="card-footer">

            

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/users/index.blade.php ENDPATH**/ ?>