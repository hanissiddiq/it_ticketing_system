<?php $__env->startSection('title', 'My Ticket'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="card">

        <div class="card-header d-flex justify-content-between align-items-center">

            <h5 class="mb-0">
                My Assigned Ticket
            </h5>

            <form method="GET">

                <input
                    type="text"
                    name="keyword"
                    class="form-control"
                    placeholder="Cari Ticket..."
                    value="<?php echo e(request('keyword')); ?>"
                >

            </form>

        </div>

        <div class="card-body table-responsive">

            <table class="table table-bordered align-middle">

                <thead>

                <tr>

                    <th width="50">No</th>

                    <th>Ticket Number</th>

                    <th>Subject</th>

                    <th>Priority</th>

                    <th>Status</th>

                    <th>Requester</th>

                    <th width="180">Action</th>

                </tr>

                </thead>

                <tbody>

                <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr>

                        <td>
                            <?php echo e($loop->iteration + ($tickets->firstItem() - 1)); ?>

                        </td>

                        <td><?php echo e($ticket->ticket_number); ?></td>

                        <td><?php echo e($ticket->subject); ?></td>

                        <td>

                            <?php

                                $priorityColor = match(strtolower($ticket->priority->name)){

                                    'low' => 'success',

                                    'medium' => 'warning',

                                    'high' => 'danger',

                                    'critical' => 'danger',

                                    default => 'secondary'

                                };

                            ?>

                            <span class="badge bg-<?php echo e($priorityColor); ?>">

                                <?php echo e($ticket->priority->name); ?>


                            </span>

                        </td>

                        <td>

                        <?php switch($ticket->status):

                            case ('NEW'): ?>
                                <span class="badge bg-secondary">
                                    NEW
                                </span>
                                <?php break; ?>

                            <?php case ('OPEN'): ?>
                                <span class="badge bg-info">
                                    OPEN
                                </span>
                                <?php break; ?>

                            <?php case ('ASSIGNED'): ?>
                                <span class="badge bg-primary">
                                    ASSIGNED
                                </span>
                                <?php break; ?>

                            <?php case ('IN_PROGRESS'): ?>
                                <span class="badge bg-warning text-dark">
                                    IN PROGRESS
                                </span>
                                <?php break; ?>

                            <?php case ('PENDING'): ?>
                                <span class="badge bg-dark">
                                    PENDING
                                </span>
                                <?php break; ?>

                            <?php case ('RESOLVED'): ?>
                                <span class="badge bg-success">
                                    RESOLVED
                                </span>
                                <?php break; ?>

                            <?php case ('CLOSED'): ?>
                                <span class="badge bg-secondary">
                                    CLOSED
                                </span>
                                <?php break; ?>

                            <?php case ('CANCELLED'): ?>
                                <span class="badge bg-danger">
                                    CANCELLED
                                </span>
                                <?php break; ?>

                            <?php default: ?>
                                <span class="badge bg-light text-dark">
                                    <?php echo e($ticket->status); ?>

                                </span>

                        <?php endswitch; ?>

                        </td>

                        <td>

                            <?php echo e($ticket->requester->name); ?>


                        </td>

                        <td>

                            <a
                                href="<?php echo e(route('itsupport.tickets.show',$ticket)); ?>"
                                class="btn btn-info btn-sm"
                            >
                                Detail
                            </a>

                            

                            <?php if(in_array($ticket->status, ['ASSIGNED', 'IN_PROGRESS', 'PENDING'])): ?>

                            
                            <form action="<?php echo e(route('itsupport.tickets.progress', $ticket)); ?>"
                                method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <input type="hidden" name="status" value="IN_PROGRESS">

                                <button type="submit"
                                        class="btn btn-warning btn-sm">
                                    In Progress
                                </button>
                            </form>

                            
                            <form action="<?php echo e(route('itsupport.tickets.progress', $ticket)); ?>"
                                method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <input type="hidden" name="status" value="PENDING">

                                <button type="submit"
                                        class="btn btn-secondary btn-sm">
                                    Pending
                                </button>
                            </form>

                            
                            <form action="<?php echo e(route('itsupport.tickets.progress', $ticket)); ?>"
                                method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                <input type="hidden" name="status" value="RESOLVED">

                                <button type="submit"
                                        class="btn btn-success btn-sm">
                                    Resolved
                                </button>
                            </form>

                        <?php endif; ?>

                        </td>

                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <tr>

                        <td colspan="7" class="text-center">

                            Tidak ada ticket.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

            <?php echo e($tickets->links()); ?>


        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/itsupport/tickets/index.blade.php ENDPATH**/ ?>