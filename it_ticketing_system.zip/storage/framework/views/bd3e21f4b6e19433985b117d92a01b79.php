<?php $__env->startSection('title','Ticket Detail'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        
        <div class="col-lg-8">

            
            <div class="card mb-3">
                <div class="card-header">
                    <strong>Ticket Information</strong>
                </div>

                <div class="card-body">

                    <table class="table table-bordered">

                        <tr>
                            <th width="220">Ticket Number</th>
                            <td><?php echo e($ticket->ticket_number); ?></td>
                        </tr>

                        <tr>
                            <th>Subject</th>
                            <td><?php echo e($ticket->subject); ?></td>
                        </tr>

                        <tr>
                            <th>Description</th>
                            <td><?php echo nl2br(e($ticket->description)); ?></td>
                        </tr>

                        <tr>
                            <th>Requester</th>
                            <td><?php echo e($ticket->requester->name); ?></td>
                        </tr>

                        <tr>
                            <th>Department</th>
                            <td><?php echo e($ticket->department->name); ?></td>
                        </tr>

                        <tr>
                            <th>Category</th>
                            <td><?php echo e($ticket->category->name); ?></td>
                        </tr>

                        <tr>
                            <th>Sub Category</th>
                            <td><?php echo e($ticket->subCategory->name); ?></td>
                        </tr>

                        <tr>
                            <th>Priority</th>
                            <td>
                                <?php switch($ticket->priority->name):

                                    case ('LOW'): ?>
                                        <span class="badge bg-success">LOW</span>
                                        <?php break; ?>

                                    <?php case ('MEDIUM'): ?>
                                        <span class="badge bg-primary">MEDIUM</span>
                                        <?php break; ?>

                                    <?php case ('HIGH'): ?>
                                        <span class="badge bg-warning text-dark">HIGH</span>
                                        <?php break; ?>

                                    <?php case ('CRITICAL'): ?>
                                        <span class="badge bg-danger">CRITICAL</span>
                                        <?php break; ?>

                                    <?php default: ?>
                                        <span class="badge bg-secondary">
                                            <?php echo e($ticket->priority->name); ?>

                                        </span>

                                <?php endswitch; ?>
                            </td>
                        </tr>

                        <tr>
                            <th>Status</th>
                            <td>

                                <?php

                                    $badge = match($ticket->status){

                                        'NEW' => 'secondary',

                                        'ASSIGNED' => 'primary',

                                        'IN_PROGRESS' => 'warning',

                                        'PENDING' => 'dark',

                                        'RESOLVED' => 'success',

                                        'CLOSED' => 'info',

                                        'CANCELLED' => 'danger',

                                        default => 'secondary'

                                    };

                                ?>

                                <span class="badge bg-<?php echo e($badge); ?>">

                                    <?php echo e($ticket->status); ?>


                                </span>

                            </td>
                        </tr>

                    </table>

                </div>
            </div>

            
            <div class="card mb-3">

                <div class="card-header">
                    <strong>Assignment Information</strong>
                </div>

                <div class="card-body">

                    <table class="table table-bordered">

                        <tr>
                            <th width="220">Assigned To</th>
                            <td><?php echo e($ticket->assignee?->name ?? '-'); ?></td>
                        </tr>

                        <tr>
                            <th>Assigned At</th>
                            <td><?php echo e(optional($ticket->assigned_at)->format('d M Y H:i') ?? '-'); ?></td>
                        </tr>

                    </table>

                </div>

            </div>

            
            <div class="card">

                <div class="card-header">
                    <strong>Attachment</strong>
                </div>

                <div class="card-body">

                    <?php $__empty_1 = true; $__currentLoopData = $ticket->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <div class="d-flex justify-content-between border rounded p-2 mb-2">

                            <div>
                                <strong><?php echo e($attachment->original_name); ?></strong><br>
                                <small><?php echo e(number_format($attachment->file_size/1024,2)); ?> KB</small>
                            </div>

                            <div>

                            <a
                                href="<?php echo e(route('itsupport.tickets.attachments.download',[$ticket,$attachment])); ?>"
                                class="btn btn-success btn-sm">

                                Download

                            </a>
                            </div>



                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <div class="alert alert-light">

                            Tidak ada attachment.

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

        
        <div class="col-lg-4">

            
            <div class="card mb-3">

                <div class="card-header">
                    <strong>Ticket Timeline</strong>
                </div>

                <div class="card-body">

                    <?php $__currentLoopData = $ticket->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="border-start border-3 border-primary ps-3 mb-3">

                            <strong><?php echo e($history->action); ?></strong>

                            <div><?php echo e($history->description); ?></div>

                            <small class="text-muted">
                                <?php echo e($history->user?->name); ?>

                                •
                                <?php echo e($history->created_at->format('d M Y H:i')); ?>

                            </small>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

            
            <div class="card mb-3">

                <div class="card-header">
                    <strong>Discussion</strong>
                </div>

                <div class="card-body">

                    <?php $__empty_1 = true; $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <div class="border rounded p-2 mb-2">

                            <strong><?php echo e($comment->user->name); ?></strong>

                            <?php if($comment->is_internal): ?>
                                <span class="badge bg-warning text-dark">
                                    Internal
                                </span>
                            <?php endif; ?>

                            <div class="mt-2">
                                <?php echo e($comment->comment); ?>

                            </div>

                            <small class="text-muted">
                                <?php echo e($comment->created_at->format('d M Y H:i')); ?>

                            </small>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <p class="text-muted">
                            Belum ada komentar.
                        </p>

                    <?php endif; ?>

                </div>

            </div>

            
            <div class="card mb-3">

                <div class="card-header">
                    <strong>Add Comment</strong>
                </div>

                <div class="card-body">

                    <form
                        action="<?php echo e(route('itsupport.comments.store',$ticket)); ?>"
                        method="POST">

                        <?php echo csrf_field(); ?>

                        <textarea
                            name="comment"
                            rows="4"
                            class="form-control mb-3"></textarea>

                        <div class="form-check mb-3">

                            <input
                                class="form-check-input"
                                type="checkbox"
                                value="1"
                                name="is_internal"
                                id="internal">

                            <label
                                class="form-check-label"
                                for="internal">

                                Internal Comment

                            </label>

                        </div>

                        <button class="btn btn-primary w-100">

                            Kirim Komentar

                        </button>

                    </form>

                </div>

            </div>

            

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/itsupport/tickets/show.blade.php ENDPATH**/ ?>