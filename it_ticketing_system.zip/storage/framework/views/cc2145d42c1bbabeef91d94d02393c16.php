<?php $__env->startSection('title','Ticket Detail'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <div class="row">

        <div class="col-lg-8">

            <div class="card mb-3">

                <div class="card-header">

                    <strong>Ticket Information</strong>

                </div>

                <div class="card-body">

                    <table class="table table-bordered">

                        <tr>
                            <th width="220">Ticket Number</th>
                            <td><?php echo e($ticket->ticket_number); ?></td>
                        </tr>

                        <tr>
                            <th>Subject</th>
                            <td><?php echo e($ticket->subject); ?></td>
                        </tr>

                        <tr>
                            <th>Description</th>
                            <td><?php echo nl2br(e($ticket->description)); ?></td>
                        </tr>

                        <tr>
                            <th>Department</th>
                            <td><?php echo e($ticket->department->name); ?></td>
                        </tr>

                        <tr>
                            <th>Category</th>
                            <td><?php echo e($ticket->category->name); ?></td>
                        </tr>

                        <tr>
                            <th>Sub Category</th>
                            <td><?php echo e($ticket->subCategory->name); ?></td>
                        </tr>

                        <tr>
                            <th>Priority</th>
                            <td>
                                <?php switch($ticket->priority->name):

                                    case ('LOW'): ?>
                                        <span class="badge bg-success">LOW</span>
                                        <?php break; ?>

                                    <?php case ('MEDIUM'): ?>
                                        <span class="badge bg-primary">MEDIUM</span>
                                        <?php break; ?>

                                    <?php case ('HIGH'): ?>
                                        <span class="badge bg-warning text-dark">HIGH</span>
                                        <?php break; ?>

                                    <?php case ('CRITICAL'): ?>
                                        <span class="badge bg-danger">CRITICAL</span>
                                        <?php break; ?>

                                    <?php default: ?>
                                        <span class="badge bg-secondary">
                                            <?php echo e($ticket->priority->name); ?>

                                        </span>

                                <?php endswitch; ?>
                            </td>
                        </tr>

                        <tr>

                            <th>Status</th>

                            <td>

                                <?php

                                    $badge = match($ticket->status){

                                        'NEW' => 'secondary',

                                        'ASSIGNED' => 'primary',

                                        'IN_PROGRESS' => 'warning',

                                        'PENDING' => 'dark',

                                        'RESOLVED' => 'success',

                                        'CLOSED' => 'info',

                                        'CANCELLED' => 'danger',

                                        default => 'secondary'

                                    };

                                ?>

                                <span class="badge bg-<?php echo e($badge); ?>">

                                    <?php echo e($ticket->status); ?>


                                </span>

                            </td>

                        </tr>

                    </table>

                </div>

            </div>

            <div class="card mb-3">

                <div class="card-header">

                    <strong>Assignment Information</strong>

                </div>

                <div class="card-body">

                    <table class="table table-bordered">

                        <tr>

                            <th width="220">

                                Assigned To

                            </th>

                            <td>

                                <?php echo e($ticket->assignee?->name ?? '-'); ?>


                            </td>

                        </tr>

                        <tr>

                            <th>

                                Assigned Date

                            </th>

                            <td>

                                <?php echo e(optional($ticket->assigned_at)->format('d M Y H:i') ?? '-'); ?>


                            </td>

                        </tr>

                    </table>

                </div>

            </div>

            <div class="card mb-3">

                <div class="card-header">

                    <strong>Attachment</strong>

                </div>

                <div class="card-body">

                    <?php $__empty_1 = true; $__currentLoopData = $ticket->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <div class="d-flex justify-content-between border rounded p-2 mb-2">

                            <div>

                                <strong>

                                    <?php echo e($attachment->original_name); ?>


                                </strong>

                                <br>

                                <small>

                                    <?php echo e(number_format($attachment->file_size/1024,2)); ?> KB

                                </small>

                            </div>

                            <div>

                                <a
                                    href="<?php echo e(route('requester.tickets.attachments.download',[$ticket,$attachment])); ?>"
                                    class="btn btn-success btn-sm">

                                    Download

                                </a>
                                <!-- Tombol Hapus Diubah Menjadi Form -->
                                <form action="<?php echo e(route('requester.tickets.attachments.destroy', [$ticket, $attachment])); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus attachment ini?')">
                                        Hapus
                                    </button>
                                </form>



                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <div class="alert alert-light">

                            Tidak ada attachment.

                        </div>

                    <?php endif; ?>

                </div>

            </div>

            







        </div>

        <div class="col-lg-4">

            <div class="card mb-3">

                <div class="card-header">

                    Ticket Timeline

                </div>

                <div class="card-body">

                    <?php $__empty_1 = true; $__currentLoopData = $ticket->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <div class="border-bottom mb-3 pb-2">

                            <strong>

                                <?php echo e($history->action); ?>


                            </strong>

                            <br>

                            <small>

                                <?php echo e($history->description); ?>


                            </small>

                            <br>

                            <small class="text-muted">

                                <?php echo e($history->user?->name); ?>


                                •

                                <?php echo e($history->created_at->format('d M Y H:i')); ?>


                            </small>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <p class="text-muted">

                            Belum ada history.

                        </p>

                    <?php endif; ?>

                </div>

            </div>

            <div class="card mb-3">

                <div class="card-header">

                    Comment

                </div>

                <div class="card-body">
                   
                    
                    <?php $__empty_1 = true; $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        
                        <?php if($comment->is_internal): ?>
                            <?php continue; ?>
                        <?php endif; ?>

                        <div class="border rounded p-2 mb-2">

                            
                            <!-- Header komentar: nama user di kiri, tombol hapus di kanan -->
            <div class="d-flex justify-content-between align-items-start">
                <strong>
                    <?php echo e($comment->user->name); ?>

                </strong>

                <?php if(auth()->id() == $comment->user_id): ?>
                    <form action="<?php echo e(route('requester.comments.destroy', [$ticket, $comment])); ?>" 
                          method="POST" 
                          class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-outline-danger border-0 p-1 lh-1" 
                                title="Hapus komentar"
                                onclick="return confirm('Hapus komentar ini?')">
                            <i class="bi bi-trash"></i>
                        </button>
                    </form>
                <?php endif; ?>
            </div>

                            <?php echo e($comment->comment); ?>

                            

                            <br>

                            <small class="text-muted">

                                <?php echo e($comment->created_at->format('d M Y H:i')); ?>


                            </small>
                            

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <p class="text-muted">

                            Belum ada komentar.

                        </p>

                    <?php endif; ?>                    

                </div>

            </div>

            <?php if($ticket->status=='RESOLVED'): ?>

                <div class="card">

                    <div class="card-body text-center">

                        <form
                            action="<?php echo e(route('requester.tickets.close',$ticket)); ?>"
                            method="POST">

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('PUT'); ?>

                            <button
                                class="btn btn-success w-100"
                                onclick="return confirm('Tutup ticket ini?')">

                                Close Ticket

                            </button>

                        </form>

                    </div>

                </div>

            <?php endif; ?>

            <div class="card mt-3">

                <div class="card-header">

                    <h5 class="mb-0">

                        <i class="bi bi-chat-dots"></i>

                        Ticket Discussion

                    </h5>

                </div>

                <div class="card-body">
                    <form
                action="<?php echo e(route('requester.comments.store',$ticket)); ?>"
                method="POST">

                <?php echo csrf_field(); ?>

                <div class="mb-3">

                    <textarea
                        name="comment"
                        rows="4"
                        class="form-control"
                        placeholder="Tulis komentar..."></textarea>

                </div>

                <div class="form-check mb-3">

                    

                </div>

                <button class="btn btn-primary">

                    <i class="bi bi-send"></i>

                    Kirim

                </button>

            </form>
            </div>

        </div>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/requester/tickets/show.blade.php ENDPATH**/ ?>