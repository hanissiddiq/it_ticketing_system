<?php echo csrf_field(); ?>

<div class="card shadow-sm mb-4">

    <div class="card-header">

        <h5 class="mb-0">

            Ticket Information

        </h5>

    </div>

    <div class="card-body">

        <div class="row">

            <div class="col-md-6 mb-3">

                <label class="fw-bold">

                    Ticket Number

                </label>

                <input
                    class="form-control"
                    readonly
                    value="<?php echo e($ticket->ticket_number); ?>">

            </div>

            <div class="col-md-6 mb-3">

                <label class="fw-bold">

                    Status

                </label>

                <input
                    class="form-control"
                    readonly
                    value="<?php echo e(str_replace('_',' ',$ticket->status)); ?>">

            </div>

        </div>

        <div class="mb-3">

            <label class="fw-bold">

                Subject

            </label>

            <input
                class="form-control"
                readonly
                value="<?php echo e($ticket->subject); ?>">

        </div>

        <div class="mb-3">

            <label class="fw-bold">

                Description

            </label>

            <textarea
                class="form-control"
                rows="4"
                readonly><?php echo e($ticket->description); ?></textarea>

        </div>

        <div class="row">

            <div class="col-md-6 mb-3">

                <label class="fw-bold">

                    Priority

                </label>

                <input
                    class="form-control"
                    readonly
                    value="<?php echo e($ticket->priority->name); ?>">

            </div>

            <div class="col-md-6 mb-3">

                <label class="fw-bold">

                    Department

                </label>

                <input
                    class="form-control"
                    readonly
                    value="<?php echo e($ticket->department->name); ?>">

            </div>

        </div>

    </div>

</div>

<div class="card shadow-sm">

    <div class="card-header">

        <h5 class="mb-0">

            Assign To IT Support

        </h5>

    </div>

    <div class="card-body">

        <div class="mb-3">

            <label class="form-label">

                IT Support

            </label>

            <select
                name="assigned_to"
                class="form-select <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                <option value="">

                    -- Select IT Support --

                </option>

                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option
                        value="<?php echo e($user->id); ?>"
                        <?php if(old('assigned_to')==$user->id): echo 'selected'; endif; ?>>

                        <?php echo e($user->name); ?>


                    </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

            <?php $__errorArgs = ['assigned_to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                <div class="invalid-feedback">

                    <?php echo e($message); ?>


                </div>

            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="mb-3">

            <label class="form-label">

                Assignment Notes

            </label>

            <textarea
                rows="4"
                name="notes"
                class="form-control"><?php echo e(old('notes')); ?></textarea>

        </div>

    </div>

</div>

<div class="mt-4">

    <button
        class="btn btn-primary">

        Assign Ticket

    </button>

    <a
        href="<?php echo e(route('tickets.show',$ticket)); ?>"
        class="btn btn-secondary">

        Cancel

    </a>

</div><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/tickets/assignment/form.blade.php ENDPATH**/ ?>