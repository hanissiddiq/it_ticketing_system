<?php $__env->startSection('content'); ?>

<div class="container">

    <div class="card">

        <div class="card-header">

            <h4 class="mb-0">

                Edit User

            </h4>

        </div>

        <div class="card-body">

            <form
                action="<?php echo e(route('users.update',$user)); ?>"
                method="POST"
                enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <?php echo method_field('PUT'); ?>

                <?php echo $__env->make('users.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </form>

        </div>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/users/edit.blade.php ENDPATH**/ ?>