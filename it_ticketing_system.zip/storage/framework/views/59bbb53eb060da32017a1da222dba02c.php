<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-3">

    <div>

        <h4 class="mb-0">

            <?php echo e($ticket->ticket_number); ?>


        </h4>

        <small class="text-muted">

            Detail Ticket Helpdesk

        </small>

    </div>

    <div>

        <a
            href="<?php echo e(route('tickets.index')); ?>"
            class="btn btn-secondary">

            <i class="bi bi-arrow-left"></i>

            Kembali

        </a>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-edit')): ?>

        <a
            href="<?php echo e(route('tickets.edit',$ticket)); ?>"
            class="btn btn-warning">

            Edit

        </a>

        <?php endif; ?>

    </div>

</div>




<div class="card h-100">

    <div class="card-header">

        <strong>

            Ticket Information

        </strong>

    </div>

    <div class="card-body">

        <table class="table table-bordered table-sm">

            <tr>
                <th width="180">Ticket Number</th>
                <td><?php echo e($ticket->ticket_number); ?></td>
            </tr>

            <tr>
                <th>Subject</th>
                <td><?php echo e($ticket->subject); ?></td>
            </tr>

            <tr>
                <th>Category</th>
                <td><?php echo e($ticket->category->name); ?></td>
            </tr>

            <tr>
                <th>Sub Category</th>
                <td><?php echo e($ticket->subCategory->name); ?></td>
            </tr>

            <tr>
                <th>Priority</th>
                <td><?php echo e($ticket->priority->name); ?></td>
            </tr>

            <tr>
                <th>Status</th>
                <td>

                    
                     <?php switch($ticket->status):

                            case ('NEW'): ?>
                                <span class="badge bg-secondary">
                                    NEW
                                </span>
                                <?php break; ?>

                            <?php case ('OPEN'): ?>
                                <span class="badge bg-info">
                                    OPEN
                                </span>
                                <?php break; ?>

                            <?php case ('ASSIGNED'): ?>
                                <span class="badge bg-primary">
                                    ASSIGNED
                                </span>
                                <?php break; ?>

                            <?php case ('IN_PROGRESS'): ?>
                                <span class="badge bg-warning text-dark">
                                    IN PROGRESS
                                </span>
                                <?php break; ?>

                            <?php case ('PENDING'): ?>
                                <span class="badge bg-dark">
                                    PENDING
                                </span>
                                <?php break; ?>

                            <?php case ('RESOLVED'): ?>
                                <span class="badge bg-success">
                                    RESOLVED
                                </span>
                                <?php break; ?>

                            <?php case ('CLOSED'): ?>
                                <span class="badge bg-success">
                                    CLOSED
                                </span>
                                <?php break; ?>

                            <?php case ('CANCELLED'): ?>
                                <span class="badge bg-danger">
                                    CANCELLED
                                </span>
                                <?php break; ?>

                            <?php default: ?>
                                <span class="badge bg-light text-dark">
                                    <?php echo e($ticket->status); ?>

                                </span>

                        <?php endswitch; ?>

                </td>

            </tr>

            <tr>
                <th>Created</th>
                <td><?php echo e($ticket->created_at->format('d M Y H:i')); ?></td>
            </tr>

            <tr>
                <th>Updated</th>
                <td><?php echo e($ticket->updated_at->format('d M Y H:i')); ?></td>
            </tr>

        </table>

    </div>

</div>






<div class="card h-100">

    <div class="card-header">

        <strong>

            Requester Information

        </strong>

    </div>

    <div class="card-body">

        <table class="table table-bordered table-sm">

            <tr>

                <th width="180">

                    Name

                </th>

                <td>

                    <?php echo e($ticket->requester->name); ?>


                </td>

            </tr>

            <tr>

                <th>

                    Department

                </th>

                <td>

                    <?php echo e($ticket->department->name); ?>


                </td>

            </tr>

            <tr>

                <th>

                    Email

                </th>

                <td>

                    <?php echo e($ticket->requester->email); ?>


                </td>

            </tr>

            <tr>

                <th>

                    Assigned To

                </th>

                <td>

                    <?php echo e(optional($ticket->assignee)->name ?? '-'); ?>


                </td>

            </tr>

            <tr>

                <th>

                    Updated By

                </th>

                <td>

                    <?php echo e(optional($ticket->updatedBy)->name ?? '-'); ?>


                </td>

            </tr>

        </table>

    </div>

</div>




<div class="card mt-3">

    <div class="card-header">

        <strong>

            Description

        </strong>

    </div>

    <div class="card-body">

        <?php echo nl2br(e($ticket->description)); ?>


    </div>

</div>



<div class="card mt-3">

    <div class="card-header d-flex justify-content-between align-items-center">

        <strong>
            Assignment Information
        </strong>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-assignment')): ?>

            <a href="<?php echo e(route('tickets.assignment.create', $ticket)); ?>"
                class="btn btn-primary btn-sm">

                <i class="bi bi-person-plus-fill"></i>

                Assign Ticket

            </a>

        <?php endif; ?>

    </div>

    <div class="card-body">

        <?php if($ticket->assignments->count()): ?>

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead class="table-light">

                        <tr>

                            <th width="50">No</th>

                            <th>Assigned By</th>

                            <th>Assigned To</th>

                            <th>Assigned At</th>

                            <th>Notes</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $ticket->assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>

                                    <?php echo e($loop->iteration); ?>


                                </td>

                                <td>

                                    <?php echo e(optional($assignment->assigner)->name); ?>


                                </td>

                                <td>

                                    <?php echo e(optional($assignment->assignee)->name); ?>


                                </td>

                                <td>

                                    <?php echo e(optional($assignment->assigned_at)->format('d M Y H:i')); ?>


                                </td>

                                <td>

                                    <?php echo e($assignment->notes ?: '-'); ?>


                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="alert alert-warning mb-0">

                Ticket ini belum pernah di-assign.

            </div>

        <?php endif; ?>

    </div>

</div>



<div class="card mt-3">

    <div class="card-header">

        <strong>

            Activity History

        </strong>

    </div>

    <div class="card-body">

        <?php if($ticket->histories->count()): ?>

            <div class="table-responsive">

                <table class="table table-striped table-bordered">

                    <thead class="table-light">

                        <tr>

                            <th width="50">No</th>

                            <th width="170">Date</th>

                            <th>User</th>

                            <th>Action</th>

                            <th>Field</th>

                            <th>Old Value</th>

                            <th>New Value</th>

                            <th>Description</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $ticket->histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td>

                                    <?php echo e($loop->iteration); ?>


                                </td>

                                <td>

                                    <?php echo e($history->created_at->format('d M Y H:i')); ?>


                                </td>

                                <td>

                                    <?php echo e(optional($history->user)->name); ?>


                                </td>

                                <td>

                                    <span class="badge bg-info">

                                        <?php echo e($history->action); ?>


                                    </span>

                                </td>

                                <td>

                                    <?php echo e($history->field ?: '-'); ?>


                                </td>

                                <td>

                                    <?php echo e($history->old_value ?: '-'); ?>


                                </td>

                                <td>

                                    <?php echo e($history->new_value ?: '-'); ?>


                                </td>

                                <td>

                                    <?php echo e($history->description); ?>


                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="alert alert-info mb-0">

                Belum ada riwayat aktivitas ticket.

            </div>

        <?php endif; ?>

    </div>

</div>




<div class="card mt-3">

    <div class="card-header d-flex justify-content-between align-items-center">

        <strong>
            Attachment
        </strong>

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-edit')): ?>

            <button
                class="btn btn-primary btn-sm"
                disabled>

                <i class="bi bi-paperclip"></i>

                Upload Attachment

            </button>

        <?php endif; ?>

    </div>

    <div class="card-body">

        <?php if(isset($ticket->attachments) && $ticket->attachments->count()): ?>

            <div class="table-responsive">

                <table class="table table-bordered table-hover">

                    <thead class="table-light">

                        <tr>

                            <th width="50">No</th>

                            <th>File Name</th>

                            <th>Uploaded By</th>

                            <th>Uploaded At</th>

                            <th width="120">Action</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php $__currentLoopData = $ticket->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attachment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <td><?php echo e($loop->iteration); ?></td>

                                <td><?php echo e($attachment->original_name); ?></td>

                                <td><?php echo e(optional($attachment->user)->name); ?></td>

                                <td><?php echo e($attachment->created_at->format('d M Y H:i')); ?></td>

                                <td>

                                    <a
                                        href="<?php echo e(asset('storage/'.$attachment->file_path)); ?>"
                                        target="_blank"
                                        class="btn btn-success btn-sm">

                                        Download

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>

                </table>

            </div>

        <?php else: ?>

            <div class="alert alert-secondary mb-0">

                Belum ada attachment.

            </div>

        <?php endif; ?>

    </div>

</div>



<div class="card mt-3">

    <div class="card-header">

        <strong>

            Action

        </strong>

    </div>

    <div class="card-body">

        <div class="d-flex flex-wrap gap-2">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-edit')): ?>

                <a
                    href="<?php echo e(route('tickets.edit',$ticket)); ?>"
                    class="btn btn-warning">

                    Edit Ticket

                </a>

            <?php endif; ?>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-assignment')): ?>

                <?php if(!$ticket->assigned_to): ?>

                    <a
                        href="<?php echo e(route('tickets.assignment.create',$ticket)); ?>"
                        class="btn btn-primary">

                        Assign IT Support

                    </a>

                <?php else: ?>

                    <a
                        href="<?php echo e(route('tickets.assignment.create',$ticket)); ?>"
                        class="btn btn-outline-primary">

                        Reassign Ticket

                    </a>

                <?php endif; ?>

            <?php endif; ?>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ticket-delete')): ?>

                <form
                    action="<?php echo e(route('tickets.destroy',$ticket)); ?>"
                    method="POST"
                    onsubmit="return confirm('Yakin ingin menghapus ticket ini?')">

                    <?php echo csrf_field(); ?>

                    <?php echo method_field('DELETE'); ?>

                    <button
                        class="btn btn-danger">

                        Delete

                    </button>

                </form>

            <?php endif; ?>


            <?php if($ticket->status=='RESOLVED'): ?>

                <button
                    class="btn btn-success"
                    disabled>

                    Ticket Resolved

                </button>

            <?php endif; ?>


            <?php if($ticket->status=='CLOSED'): ?>

                <button
                    class="btn btn-secondary"
                    disabled>

                    Ticket Closed

                </button>

            <?php endif; ?>


            <a
                href="<?php echo e(route('helpdesk.dashboard')); ?>"
                class="btn btn-outline-secondary">

                Back

            </a>

        </div>

    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.main', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\it_ticketing_system\resources\views/helpdesk/tickets/show.blade.php ENDPATH**/ ?>